import React from 'react';
import CapacitacionList from './CapacitacionList';

const Capacitaciones = () => {
  return (
    <div>
      <h2>Gestión de Capacitaciones</h2>
      <CapacitacionList />
    </div>
  );
};

export default Capacitaciones;
