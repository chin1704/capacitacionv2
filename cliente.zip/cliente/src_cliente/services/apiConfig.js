//export const BASE_API_URL = 'https://newfreshstudio.com:5001';
export const BASE_API_URL = 'http://localhost:5000';

export const API_URL = `${BASE_API_URL}/api/fcc`;	
export const API_IMAGE_URL = `${BASE_API_URL}`;


